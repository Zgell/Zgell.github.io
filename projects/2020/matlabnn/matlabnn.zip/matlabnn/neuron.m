classdef neuron < handle
    properties
        synaptic_weights = (2 * rand(1,3))-1;
    end
    methods
        function o = neuron(obj)
           %Constructor function
           rng('shuffle');
           obj.synaptic_weights = [0.5 0.5 0.5];
        end
        function s = sig(~, x)
           s = (exp(x))./(exp(x)+1);
        end
        function sd = sigderiv(~, x)
            sd = x .* (1-x);
        end
        function t = think(obj, input) %Now functions the same as Python
           s = size(input);
           t = zeros(s(1), 1);
           ii = 1;
           while (ii <= s(1))
               t(ii,:) = dot(input(ii,:), obj.synaptic_weights);
               ii = ii + 1;
           end
           t = obj.sig(t);
        end
        function train(obj, t_inputs, t_outputs, iterations)
           ii = 1;
           while (ii <= iterations)
              outputs = obj.think(t_inputs);
              error = t_outputs - outputs;
              w = error .* obj.sigderiv(outputs);
              stin = size(t_inputs);
              adjustments = zeros(stin(1)-1,1);
              t_inputs_t = t_inputs';
              j = 1;
              while (j < stin(1))
                 adjustments(j,:) = dot(t_inputs_t(j,:), w);
                 j = j+1;
              end
              obj.synaptic_weights = obj.synaptic_weights + adjustments;
              obj.synaptic_weights = obj.synaptic_weights(:,1);
              disp(obj.synaptic_weights);
              ii = ii + 1;
           end
           disp(obj.synaptic_weights);
           
        end
    end
end