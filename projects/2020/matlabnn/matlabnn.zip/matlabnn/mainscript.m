clear;
clc;

NN = neuron;

disp("Starting Weights: ");
disp(NN.synaptic_weights);

training_inputs =  [0 0 1;
                    1 1 1;
                    1 0 1;
                    0 1 1];
training_outputs = [0;
                    1;
                    1;
                    0];
NN.train(training_inputs, training_outputs, 1000);

disp("Synaptic Weights AFTER Training: ");
disp(NN.synaptic_weights');
disp("Test Scenario");
A = input("Value 1: ");
B = input("Value 2: ");
C = input("Value 3: ");
fprintf("New Inputs: %d %d %d \n", A, B, C);
fprintf("Output: %f \n", NN.think([A B C]));